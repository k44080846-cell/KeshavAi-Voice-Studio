package com.keshav.aivoicestudio

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.File
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var recorder: MediaRecorder? = null
    private var player: MediaPlayer? = null
    private var currentAudio: Uri? = null
    private var recordingFile: File? = null
    private lateinit var status: TextView
    private lateinit var language: Spinner
    private lateinit var speechText: EditText
    private val languages = listOf("हिंदी" to Locale("hi", "IN"), "English" to Locale.US,
        "বাংলা" to Locale("bn", "IN"), "اردو" to Locale("ur", "PK"), "தமிழ்" to Locale("ta", "IN"))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildHome()
    }

    private fun buildHome() {
        val scroll = ScrollView(this)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 32)
            setBackgroundColor(0xFF100D1D.toInt())
        }
        scroll.addView(page)
        setContentView(scroll)

        page.addView(label("KESHAV AI VOICE STUDIO", 25, 0xFFFFFFFF.toInt(), true))
        page.addView(label("Voice • Music • Beat • Creator Tools", 14, 0xFFBDB3D8.toInt()))
        status = label("तैयार हो रहा है…", 13, 0xFFFFD180.toInt())
        page.addView(status)
        page.addView(section("🎙️ AI VOICE GENERATOR"))
        speechText = EditText(this).apply {
            hint = "यहाँ अपना टेक्स्ट लिखें…"
            setHintTextColor(0xFF8E879F.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xFF292338.toInt())
            minLines = 4
            gravity = Gravity.TOP
            setPadding(14, 12, 14, 12)
        }
        page.addView(speechText, matchWrap())
        language = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                languages.map { it.first })
        }
        page.addView(language, matchWrap())
        page.addView(button("▶ आवाज़ सुनें") { speak() })
        page.addView(button("■ आवाज़ रोकें") { tts?.stop(); status.text = "आवाज़ रोक दी गई" })

        page.addView(section("🎧 RECORDING & AUDIO"))
        page.addView(button("● अपनी आवाज़ रिकॉर्ड करें") { startRecording() })
        page.addView(button("■ रिकॉर्डिंग बंद करें") { stopRecording() })
        page.addView(button("＋ फोन से ऑडियो चुनें") { chooseAudio() })
        page.addView(button("▶ चुना हुआ ऑडियो चलाएँ") { playAudio() })
        page.addView(button("■ ऑडियो रोकें") { stopAudio() })

        page.addView(section("🎼 MUSIC & BEAT STUDIO"))
        page.addView(label("ऑडियो चुनकर ऊपर Preview कर सकते हैं। मल्टी-ट्रैक मिक्सिंग, बीट सिंक, पिच/टेम्पो और MP3 मिक्स-डाउन अगले निर्माण चरण में जोड़े जाएँगे।", 14, 0xFFD8D0E8.toInt()))
        page.addView(button("अपनी म्यूजिक फाइल चुनें") { chooseAudio() })

        page.addView(section("🤖 AI MUSIC MANAGER"))
        page.addView(label("गीत के बोल और म्यूजिक स्टाइल के आधार पर AI बीट/अरेंजमेंट बनाने के लिए सुरक्षित AI सर्वर कनेक्शन और API की जरूरत होगी।", 14, 0xFFD8D0E8.toInt()))

        page.addView(section("🔐 OWNER ADMIN PANEL"))
        page.addView(label("यह डेमो स्क्रीन है। असली Owner-only अपडेट और फीचर कंट्रोल के लिए सर्वर लॉगिन, सुरक्षित डेटाबेस और रोल परमिशन जोड़ना जरूरी है।", 14, 0xFFD8D0E8.toInt()))
        page.addView(button("Owner Panel खोलें") { showOwnerPanel() })

        page.addView(section("🤖 KAJAL – OFFICIAL AI SUPPORT"))
        page.addView(label("काजल ऐप की हेल्प असिस्टेंट है। अपनी समस्या लिखें; यह शुरुआती वर्जन सामान्य troubleshooting सुझाव देगा। असली AI diagnosis के लिए सुरक्षित backend/API अगली development stage में जोड़ना होगा।", 14, 0xFFD8D0E8.toInt()))
        val issueBox = EditText(this).apply {
            hint = "अपनी समस्या या Error यहाँ लिखें…"
            setHintTextColor(0xFF8E879F.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xFF292338.toInt())
            minLines = 3
            gravity = Gravity.TOP
            setPadding(14, 12, 14, 12)
        }
        page.addView(issueBox, matchWrap())
        val kajalReply = label("नमस्ते! मैं काजल हूँ। बताइए, ऐप में क्या परेशानी आ रही है?", 14, 0xFFE4C9FF.toInt())
        page.addView(kajalReply)
        page.addView(button("🎙️ काजल से बोलकर बात करें") {
            startKajalVoiceInput()
        })
        page.addView(button("काजल से मदद लें") {
            val problem = issueBox.text.toString().trim()
            if (problem.isEmpty()) {
                issueBox.error = "पहले अपनी समस्या लिखें"
            } else {
                kajalReply.text = kajalSuggestion(problem)
                speakKajalReply(kajalReply.text.toString())
            }
        })
        page.addView(button("Support Report शेयर करें") {
            val problem = issueBox.text.toString().trim()
            if (problem.isEmpty()) {
                issueBox.error = "पहले समस्या लिखें"
            } else {
                val report = "Keshav AI Voice Studio – Support Report\\n\\nUser issue: $problem\\nApp version: 1.0.0\\nDevice: ${Build.MANUFACTURER} ${Build.MODEL}\\nAndroid: ${Build.VERSION.RELEASE}\\n\\nकृपया इस समस्या की जाँच करें।"
                val share = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, "Keshav AI Voice Studio Support Report")
                    putExtra(Intent.EXTRA_TEXT, report)
                }
                startActivity(Intent.createChooser(share, "Support Report भेजें"))
            }
        })

        page.addView(section("ℹ️ ABOUT"))
        page.addView(label("Version 1.0.0 • Keshav AI Voice Studio\nOffline TTS आपके फोन में उपलब्ध आवाज़ों पर निर्भर है।", 13, 0xFFBDB3D8.toInt()))
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            this.text = text
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, 8, 0, 8)
        }

    private fun section(text: String) = label(text, 18, 0xFFE4C9FF.toInt(), true).apply {
        setPadding(0, 22, 0, 8)
    }

    private fun button(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        setTextColor(0xFFFFFFFF.toInt())
        setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF6741A5.toInt()))
        setOnClickListener { action() }
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = 10 }

    override fun onInit(statusCode: Int) {
        ttsReady = statusCode == TextToSpeech.SUCCESS
        if (ttsReady) {
            status.text = "Voice engine तैयार है। आवाज़ें फोन के TTS इंजन से मिलेंगी।"
            setTtsLanguage()
        } else status.text = "फोन का Text-to-Speech इंजन उपलब्ध नहीं है।"
    }

    private fun setTtsLanguage() {
        if (!ttsReady) return
        val locale = languages.getOrNull(language.selectedItemPosition)?.second ?: Locale("hi", "IN")
        val result = tts?.setLanguage(locale)
        status.text = if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED)
            "इस भाषा की आवाज़ फोन में उपलब्ध नहीं है। Google Speech Services में voice pack डाउनलोड करें।"
        else "भाषा चुनी गई: ${languages[language.selectedItemPosition].first}"
    }

    private fun speak() {
        if (!ttsReady) { status.text = "Voice engine अभी तैयार नहीं है"; return }
        val text = speechText.text.toString().trim()
        if (text.isEmpty()) { speechText.error = "पहले टेक्स्ट लिखें"; return }
        setTtsLanguage()
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "keshav_voice")
    }

    private fun startRecording() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 42); return
        }
        try {
            val dir = getExternalFilesDir(null) ?: filesDir
            recordingFile = File(dir, "Keshav_recording_${System.currentTimeMillis()}.m4a")
            recorder = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()
            recorder?.apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setOutputFile(recordingFile!!.absolutePath)
                prepare(); start()
            }
            status.text = "रिकॉर्डिंग चालू है…"
        } catch (e: Exception) {
            status.text = "रिकॉर्डिंग शुरू नहीं हुई: ${e.localizedMessage}"
            recorder?.release(); recorder = null
        }
    }

    private fun stopRecording() {
        try {
            recorder?.stop()
            status.text = "रिकॉर्डिंग सेव हुई: ${recordingFile?.name}"
            currentAudio = Uri.fromFile(recordingFile)
        } catch (_: Exception) {
            status.text = "रिकॉर्डिंग बहुत छोटी थी या सेव नहीं हो सकी।"
        } finally {
            recorder?.release(); recorder = null
        }
    }

    private fun chooseAudio() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "audio/*"
        }
        startActivityForResult(intent, 77)
    }

    @Deprecated("Deprecated by Android; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 77 && resultCode == RESULT_OK) {
            currentAudio = data?.data
            status.text = "ऑडियो चुना गया: ${currentAudio?.lastPathSegment ?: "फाइल"}"
        } else if (requestCode == 78 && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(
                android.speech.RecognizerIntent.EXTRA_RESULTS
            )?.firstOrNull().orEmpty()
            if (spoken.isNotBlank()) {
                val answer = kajalSuggestion(spoken)
                AlertDialog.Builder(this)
                    .setTitle("Kajal AI – Voice Support")
                    .setMessage("आपने कहा: $spoken\\n\\n$answer")
                    .setPositiveButton("ठीक है", null)
                    .show()
                speakKajalReply(answer)
            }
        }
    }

    private fun playAudio() {
        val uri = currentAudio
        if (uri == null) { status.text = "पहले ऑडियो चुनें या रिकॉर्ड करें"; return }
        try {
            stopAudio()
            player = MediaPlayer().apply {
                setDataSource(this@MainActivity, uri)
                setOnPreparedListener { it.start(); status.text = "ऑडियो चल रहा है…" }
                setOnCompletionListener { status.text = "ऑडियो पूरा हुआ"; stopAudio() }
                prepareAsync()
            }
        } catch (e: Exception) { status.text = "ऑडियो नहीं चल पाया: ${e.localizedMessage}" }
    }

    private fun stopAudio() {
        try { player?.stop() } catch (_: Exception) {}
        player?.release(); player = null
    }

    private fun startKajalVoiceInput() {
        val intent = Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(android.speech.RecognizerIntent.EXTRA_PROMPT,
                "काजल से अपनी समस्या बोलकर बताइए")
        }
        try {
            startActivityForResult(intent, 78)
        } catch (_: Exception) {
            status.text = "इस फोन में Speech Recognition उपलब्ध नहीं है।"
        }
    }

    private fun speakKajalReply(reply: String) {
        if (!ttsReady) {
            status.text = "फोन का Text-to-Speech इंजन तैयार नहीं है।"
            return
        }
        // Hindi voice is the default for Kajal. English text can be spoken by switching
        // the phone's TTS language to English in the voice settings.
        tts?.setLanguage(Locale("hi", "IN"))
        tts?.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "kajal_reply")
    }

    private fun kajalSuggestion(problem: String): String {
        val p = problem.lowercase(Locale.ROOT)
        val advice = when {
            listOf("voice", "आवाज़", "आवाज", "tts", "बोल").any { p.contains(it) } ->
                "Voice की समस्या के लिए: 1) फोन में Settings > General management > Text-to-speech output खोलें। 2) Google Speech Services चुनें। 3) हिंदी/चुनी हुई भाषा का voice data डाउनलोड करें। 4) ऐप दोबारा खोलकर कोशिश करें।"
            listOf("record", "रिकॉर्ड", "mic", "माइक").any { p.contains(it) } ->
                "Recording के लिए: 1) ऐप को Microphone permission दें। 2) फोन का माइक्रोफोन किसी दूसरी ऐप में व्यस्त न हो। 3) थोड़ी खाली storage रखें। 4) फिर रिकॉर्डिंग शुरू करें।"
            listOf("audio", "music", "गाना", "म्यूजिक", "ऑडियो").any { p.contains(it) } ->
                "Audio के लिए: 1) फोन से कोई सामान्य MP3/M4A फाइल चुनें। 2) फाइल को किसी दूसरे player में चलाकर देखें। 3) ऐप को दोबारा खोलें। ध्यान दें: इस MVP में अभी full multi-track mixing उपलब्ध नहीं है।"
            listOf("download", "डाउनलोड", "zip", "apk", "install", "इंस्टॉल").any { p.contains(it) } ->
                "Download/Install के लिए: 1) ZIP पूरी तरह डाउनलोड करें। 2) फाइल मैनेजर से Extract करें। 3) AndroidIDE में extracted project folder खोलें। 4) Gradle sync पूरा होने दें। APK अभी इस ZIP में शामिल नहीं है; उसे build करना होगा।"
            listOf("error", "एरर", "crash", "बंद", "खुल").any { p.contains(it) } ->
                "कृपया ऐप बंद करके दोबारा खोलें, इंटरनेट/स्टोरेज जाँचें और वही कदम फिर करें। Error का पूरा संदेश या स्क्रीनशॉट Support Report के साथ भेजें। इस शुरुआती काजल में अभी server-based automatic error diagnosis नहीं है।"
            else ->
                "पहले ऐप बंद करके दोबारा खोलें। समस्या फिर आए तो Error का पूरा संदेश, आपने उससे पहले क्या किया था, और फोन का Android version लिखकर Support Report शेयर करें। गहरी AI जाँच के लिए secure support server अगली stage में जोड़ा जाएगा।"
        }
        return "काजल: नमस्ते! आपकी समस्या समझने की कोशिश करती हूँ।\\n\\n$advice\\n\\nअगर समस्या बनी रहे, तो Support Report शेयर करें।"
    }

    private fun showOwnerPanel() {
        val pin = EditText(this).apply { hint = "Demo PIN (1234)"; inputType = 2 }
        AlertDialog.Builder(this)
            .setTitle("Owner Panel – Demo")
            .setMessage("यह केवल लोकल डेमो लॉक है, सुरक्षित Owner authentication नहीं।")
            .setView(pin)
            .setPositiveButton("खोलें") { _, _ ->
                if (pin.text.toString() == "1234") {
                    AlertDialog.Builder(this).setTitle("Owner Dashboard")
                        .setMessage("डेमो में: App version 1.0.0\nServer-based Owner login और update controls अभी जोड़ने बाकी हैं।")
                        .setPositiveButton("ठीक है", null).show()
                } else Toast.makeText(this, "गलत PIN", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("रद्द", null).show()
    }

    override fun onDestroy() {
        stopAudio()
        recorder?.release()
        tts?.stop(); tts?.shutdown()
        super.onDestroy()
    }
}
