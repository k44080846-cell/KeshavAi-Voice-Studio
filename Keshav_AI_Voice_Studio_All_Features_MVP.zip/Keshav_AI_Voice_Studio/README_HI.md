# Keshav AI Voice Studio — Android MVP

## इस प्रोजेक्ट में अभी क्या काम करता है
- Android ऐप का Home screen और feature sections
- फोन के Text-to-Speech इंजन से उपलब्ध भाषाओं में टेक्स्ट बोलना
- माइक्रोफोन से अपनी आवाज़ रिकॉर्ड करना और ऐप के निजी फोल्डर में सेव करना
- फोन से audio file चुनना और preview/playback करना
- डेमो Owner panel (PIN 1234)

## जरूरी सीमाएँ — साफ जानकारी
यह पहला installable-source MVP है, पूरा commercial AI music product नहीं।
- AI voice cloning / celebrity voice imitation शामिल नहीं है।
- कई भाषाओं/आवाज़ों की उपलब्धता फोन में डाउनलोड किए गए TTS voice packs पर निर्भर है।
- AI cloud voice generation के लिए backend + provider API और billing/security setup चाहिए।
- Multi-track waveform editor, beat-sync, pitch/tempo processing, music generation और MP3 mix export अभी आगे के development tasks हैं।
- Owner PIN 1234 केवल demo है। इसे production में इस्तेमाल न करें। असली owner-only panel के लिए server-side authentication/roles जरूरी हैं।

## Build करने का तरीका
1. Android Studio या AndroidIDE में इस project folder को खोलें।
2. Gradle sync करें (पहली बार इंटरनेट चाहिए)।
3. Android SDK Platform 35 और JDK 17 उपलब्ध रखें।
4. Build > Build APK(s) चुनें।
5. APK सामान्यतः `app/build/outputs/apk/debug/app-debug.apk` में बनेगा।

## मोबाइल पर
AndroidIDE जैसे IDE में project खोलने की कोशिश कर सकते हैं। यदि Gradle/SDK setup में error आए तो error का screenshot भेजें। Samsung A14 5G के 8GB RAM variant पर छोटा project build हो सकता है, लेकिन पहली Gradle sync में समय और खाली storage चाहिए।

## App identity
- App name: Keshav AI Voice Studio
- Application ID: com.keshav.aivoicestudio
- Version: 1.0.0


## नया फीचर: Kajal – Official AI Support (प्रारंभिक)
- ऐप में काजल हेल्प सेक्शन जोड़ा गया है।
- Voice, recording, audio, download/install और सामान्य error पर शुरुआती troubleshooting सुझाव देती है।
- Support Report में समस्या, ऐप version, फोन model और Android version जोड़कर शेयर कर सकते हैं।
- स्पष्ट सीमा: अभी यह rule-based शुरुआती सहायता है, पूर्ण AI चैट/स्वचालित crash diagnosis नहीं। असली AI के लिए सुरक्षित backend/API, error logging की सहमति/गोपनीयता व्यवस्था और owner support dashboard जोड़ना होगा।


## Kajal Voice Support – नया अपडेट
- काजल से बोलकर समस्या बताने के लिए Android Speech Recognizer बटन जोड़ा गया है।
- काजल के शुरुआती troubleshooting जवाब फोन के Text-to-Speech इंजन से आवाज़ में सुनाए जाते हैं।
- हिंदी voice प्राथमिक है; अंग्रेज़ी voice फोन के उपलब्ध TTS voice/language pack पर निर्भर करेगी।
- यह अभी voice-enabled rule-based help है, ChatGPT जैसी live generative AI conversation नहीं।
- पूर्ण हिंदी/अंग्रेज़ी AI voice conversation के लिए secure backend, speech-to-text/voice API credentials, streaming audio और privacy/consent controls जोड़ने होंगे।
